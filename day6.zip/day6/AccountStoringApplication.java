package com.day6;

import java.sql.*;
class AccountStoringApplication
{
    public static void main(String[] args) throws ClassNotFoundException, SQLException
    {
    	String url = "jdbc:mysql://localhost:3306/bank";
		String user = "root";
		 String pass = "pwd123@";
     Class.forName("com.mysql.cj.jdbc.Driver");
     Connection con = DriverManager.getConnection(url,user,pass);
     Statement st = con.createStatement();
        int c = st.executeUpdate("insert into account values(1007, 'Shubham', 5000)");
        System.out.println(c + "account stored successfully");
        int c1 = st.executeUpdate("insert into account values(1008, 'Shravan', 5500)");
        System.out.println(c1 + " more account stored successfully");
        st.close();
        con.close();
    }
}