package com.day6;

import java.sql.*;
class UpdateAccountApplication 
{
    public static void main (String[]args) throws ClassNotFoundException, SQLException 
    {
    	 String url = "jdbc:mysql://localhost:3306/bank";
 		String user = "root";
 		 String pass = "pwd123@";
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection(url,user,pass);
        Statement st = con.createStatement ();
        int rows = st.executeUpdate ("update account set balance = balance+2000");
        System.out.println (rows + " rows modified");    
        st.close ();    
        con.close ();
    } 
}