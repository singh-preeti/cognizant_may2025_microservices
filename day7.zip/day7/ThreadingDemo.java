package com.day7;

public class ThreadingDemo
{
    public static void main (String[]args)
    {
        Thread ct = Thread.currentThread ();
        System.out.println (ct);
        System.out.println (ct.getName ());
        System.out.println (ct.getPriority ());
        System.out.println (ct.getThreadGroup ());
    }
}