package com.day7;

public class ThreadExample implements Runnable{
	public void run()
	{
		System.out.println("running...");
	}
  // getPriority(0 to 10) // windows os thread priority not allowed
	  public static void main(String[] args) {
		  ThreadExample runn = new ThreadExample();
		  Thread  t1 = new Thread(runn);
		   t1.start(); 
//		   ThreadExample t2 = new ThreadExample();
//		   t2.start();
		   // allocate the required resource and invoke run method
	}
}
