package com.day8;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Shared resource
class OrderProcessor {
    private final Queue<String> orderQueue = new LinkedList<>();

    public synchronized void placeOrder(String order) {
        orderQueue.add(order);
        System.out.println(Thread.currentThread().getName() + " placed order: " + order);
        notify(); // Notify inventory thread
    }

    public synchronized String processOrder() {
        while (orderQueue.isEmpty()) {
            try {
                wait(); // Wait for an order to be placed
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        return orderQueue.poll();
    }
}

// Producer: Customer placing orders
class CustomerThread implements Runnable {
    private final OrderProcessor processor;
    private final String customerName;

    public CustomerThread(OrderProcessor processor, String customerName) {
        this.processor = processor;
        this.customerName = customerName;
    }

    @Override
    public void run() {
        String order = "Item_" + (int)(Math.random() * 1000);
        processor.placeOrder(customerName + "-" + order);
    }
}

// Consumer: Inventory checking and processing orders
class InventoryThread extends Thread {
    private final OrderProcessor processor;

    public InventoryThread(OrderProcessor processor) {
        this.processor = processor;
    }

    @Override
    public void run() {
        while (true) {
            String order = processor.processOrder();
            System.out.println("Inventory processed: " + order);
            try {
                Thread.sleep(1000); // Simulate processing delay
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}

// Main class
public class ECommerceApp {
    public static void main(String[] args) {
        OrderProcessor processor = new OrderProcessor();

        // Start inventory thread
        InventoryThread inventory = new InventoryThread(processor);
        inventory.start();

        // Thread pool to simulate multiple customers
        ExecutorService executor = Executors.newFixedThreadPool(5);

        // Simulate 10 customers placing orders
        for (int i = 1; i <= 10; i++) {
            executor.execute(new CustomerThread(processor, "Customer" + i));
        }

        executor.shutdown();
    }
}

