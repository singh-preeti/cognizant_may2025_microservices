package com.day8;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFileExample {
	
	public static void main(String[] args) {
		try(FileWriter writer =new FileWriter("cognizant.txt",true)){
			//writer.write("Appended text");
			//writer.write("Hello Cognizant's new employees \n");
			writer.write("Its your training time !");
		}
		catch(IOException ex) {
			System.out.println(ex);
		}
	}

}
