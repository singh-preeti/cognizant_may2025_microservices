package com.day7;

class OrderQueue {
    private String order;
    private boolean hasOrder = false;

    // Place Order - Producer
    public synchronized void placeOrder(String order) {
        while (hasOrder) {
            try {
                wait(); // wait till previous order is processed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        this.order = order;
        System.out.println("Customer placed order: " + order);
        hasOrder = true;
        notify(); // Notify warehouse
    }

    // Process Order - Consumer
    public synchronized void processOrder() {
        while (!hasOrder) {
            try {
                wait(); // wait till order is placed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Warehouse processed order: " + order);
        hasOrder = false;
        notify(); // Notify customer that it's ready for next order
    }
}

// Customer Thread
class Customer extends Thread {
    private OrderQueue queue;

    public Customer(OrderQueue queue) {
        this.queue = queue;
    }

    public void run() {
        String[] orders = {"Laptop", "Mobile", "Headphones"};
        for (String order : orders) {
            queue.placeOrder(order);
            try {
                Thread.sleep(1000); // Delay between orders
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

// Warehouse Thread
class Warehouse extends Thread {
    private OrderQueue queue;

    public Warehouse(OrderQueue queue) {
        this.queue = queue;
    }

    public void run() {
        for (int i = 0; i < 3; i++) {
            queue.processOrder();
            try {
                Thread.sleep(1500); // Simulate time to pack order
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

// Main Class
public class ECommerceApp {
    public static void main(String[] args) {
        OrderQueue queue = new OrderQueue();
        Customer customer = new Customer(queue);
        Warehouse warehouse = new Warehouse(queue);

        customer.start();
        warehouse.start();
    }
}
