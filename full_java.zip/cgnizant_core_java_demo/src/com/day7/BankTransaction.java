package com.day7;
//interthread communication 
// wait(), notify(),notifyAll()
class BankAccount {
    private int balance = 0;

    // Withdraw method
    synchronized void withdraw(int amount) {
        System.out.println("Trying to withdraw: " + amount);
        while (balance < amount) {
            System.out.println("Insufficient balance. Waiting for deposit...");
            try {
                wait(); // Wait for deposit
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        balance -= amount;
        System.out.println("Withdrawal successful. Remaining Balance: " + balance);
    }

    // Deposit method
    synchronized void deposit(int amount) {
        System.out.println("Depositing: " + amount);
        balance += amount;
        System.out.println("Deposit successful. Current Balance: " + balance);
        notify(); // Notify waiting withdrawal thread
    }
}

class WithdrawThread extends Thread {
    BankAccount account;

    WithdrawThread(BankAccount account) {
        this.account = account;
    }

    public void run() {
        account.withdraw(1000);
    }
}

class DepositThread extends Thread {
    BankAccount account;

    DepositThread(BankAccount account) {
        this.account = account;
    }

    public void run() {
        try {
            Thread.sleep(10000); // Simulate deposit delay
        } catch (InterruptedException e) {}
        account.deposit(2000);
    }
}

public class BankTransaction {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();
        new WithdrawThread(account).start();
        new DepositThread(account).start();
    }
}
