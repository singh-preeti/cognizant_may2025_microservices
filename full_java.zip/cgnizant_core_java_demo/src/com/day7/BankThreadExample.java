package com.day7;
class ThreadDemo implements Runnable{
	
	public void run() {
		for(int i = 1 ; i<=10 ; i++) {
			System.out.println("Threads" +i);
		}
	}
}

public class BankThreadExample  {
	
	public static void main(String[] args) {
		ThreadDemo t1 = new ThreadDemo();
		Thread th1 = new Thread(t1);
		th1.start();
	}

}
