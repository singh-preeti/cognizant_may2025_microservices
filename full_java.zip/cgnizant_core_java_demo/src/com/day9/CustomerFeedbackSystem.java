package com.day9;

import java.io.*;
import java.util.Scanner;

public class CustomerFeedbackSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String feedbackFile = "feedback.txt";

        // Step 1: Take feedback input from user
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        System.out.print("Enter your feedback: ");
        String feedback = scanner.nextLine();

        // Step 2: Write the feedback to file using BufferedWriter
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(feedbackFile, true))) {
            writer.write("Customer: " + name + "\n");
            writer.write("Feedback: " + feedback + "\n");
            writer.write("------\n");
            System.out.println("\n✅ Feedback submitted successfully!");
        } catch (IOException e) {
            System.out.println(" Error writing feedback.");
            e.printStackTrace();
        }

        // Step 3: Read and display all feedback using BufferedReader
        System.out.println("\n=== All Feedback Entries ===");
        try (BufferedReader reader = new BufferedReader(new FileReader(feedbackFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println(" Error reading feedback.");
            e.printStackTrace();
        }

        scanner.close();
    }
}
