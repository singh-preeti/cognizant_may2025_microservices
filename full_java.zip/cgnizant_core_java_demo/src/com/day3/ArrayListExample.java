package com.day3;

import java.util.ArrayList;
import java.util.List;
class Fruits{
	
	String fruit_name;
	int amount;
	int price;
	
	public Fruits(String fruit_name, int amount, int price) {
		super();
		this.fruit_name = fruit_name;
		this.amount = amount;
		this.price = price;
	}
	public String getFruit_name() {
		return fruit_name;
	}
	public void setFruit_name(String fruit_name) {
		this.fruit_name = fruit_name;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Fruits [fruit_name=" + fruit_name + ", amount=" + amount + ", price=" + price + "]";
	}

	
	
}
public class ArrayListExample {
	int a=10,b=30,c=56;
	Integer a1 = new Integer(10);
	//String fruits = "Apple","Banana","Kiwi";
	
	public static void main(String[] args) {
		List<Fruits> fruits = new ArrayList();
		fruits.add(new Fruits(
				"Apple",2,200));
		fruits.add(new Fruits("Kiwi",3,400));
		System.out.println(fruits);
	}

}
