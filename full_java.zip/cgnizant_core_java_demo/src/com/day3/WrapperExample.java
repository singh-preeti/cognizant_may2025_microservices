package com.day3;

public class WrapperExample
{
    public static void main (String[]args)
    {
    	double d = 100.0;
        String i = "100";
        // Wrapper class accepts only string numeric values 
        int k = Integer.parseInt (i);
        double m = Double.parseDouble ("10");
        System.out.println (k);
        System.out.println (m);
        //java 1.5
        boolean status = Boolean.parseBoolean ("false");
        System.out.println (status);
        
        
        // primitive to object
                int a = 100; // Primitive data type
                Integer I = a; // Autoboxing will occur internally.
                
                // object to primitive
                Integer a1 = new Integer (15); // Wrapper class object
                int I1 = a1;   // Unboxing will occur internally.
            
    }
}