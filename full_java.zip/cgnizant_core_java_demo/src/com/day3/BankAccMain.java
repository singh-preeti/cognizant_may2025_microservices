package com.day3;

public class BankAccMain {
	public static void main(String[] args) {
		BankAccount acc = new BankAccount(1000,"Preetti");
		System.out.println("Account holder" + acc.getAcc_holder());
		System.out.println("Balance" + acc.getBalance());
		acc.deposit(2000.0);
		acc.withdraw(500.0);
		
		System.out.println("Balance" +acc.getBalance());
	}

}
