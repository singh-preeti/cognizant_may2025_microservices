package com.day5;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapExample {
	public static void main(String[] args) {
		
		//create a map
		//Map<String,Integer> map1 = new LinkedHashMap<>();
		Map<String,Integer> map1 = new TreeMap<>();
		//insert some value
		map1.put("Tv", 50000);
		map1.put("Mobile", 40000);
		map1.put("Oven", 20000);
		map1.put("Laptop",80000);
		System.out.println(map1);
		
		//traverse through map  using for each
		
		for(Map.Entry<String, Integer> prod :map1.entrySet()) {
			//System.out.println(prod.getKey());
			System.out.println(prod.getValue());
			
		}
	}

}
