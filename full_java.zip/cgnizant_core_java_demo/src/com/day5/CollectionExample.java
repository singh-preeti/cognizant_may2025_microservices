package com.day5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

class Student{
	
	String name;
	int id;
	int roll_no;
	
	public Student(String name, int id, int roll_no) {
		super();
		this.name = name;
		this.id = id;
		this.roll_no = roll_no;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", id=" + id + ", roll_no=" + roll_no + "]";
	}

	
	
}
public class CollectionExample {

	public static void main(String[] args) {
		
		List<String> student = new ArrayList();
		student.add("Anurag");
		student.add("Shubham");
		student.add("Kunal");
		student.add("Kashyap");
		student.add("Shravan");
		student.add("Bala");
		
		List<Student> obj = new ArrayList();
		obj.add(new Student("Arun",101,20));
		obj.add(new Student("Akash",102,21));
		System.out.println(obj);
		
		System.out.println(student);
		student.remove(0);
		System.out.println(student);
		System.out.println(student.contains("Mayank"));
		
		
		
		List<String> student1 = new LinkedList();
		student1.add("Anurag");
		student1.add("Shubham");
		student1.add("Kunal");
		student1.add("Kashyap");
		student1.add("Shravan");
		student1.add("Bala");
		
		System.out.println(student1);
		student1.remove(0);
		System.out.println(student1);
		System.out.println(student1.contains("Mayank"));
		
		Set<Integer> value = new HashSet();
		value.add(10);
		value.add(20);
		value.add(10);
		
		System.out.println(value);
		
		Set<Integer> value1 = new TreeSet();
		value1.add(10);
		value1.add(20);
		value1.add(10);
		
		System.out.println(value1);
		
		Map<Integer,String> user = new HashMap<>();
		user.put(101,"Kunal");
		user.put(102, "Sushma");
		
		System.out.println(user);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
