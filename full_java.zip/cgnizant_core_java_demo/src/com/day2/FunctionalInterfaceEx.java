package com.day2;
//java 8 feature where in functional interface there should only one abstract method 
// and it can have multiple default, and static methods
@FunctionalInterface
// Sam single abstract method 
interface Bonus{
	public void showSalary();
	 default void calculate_Bonus() {
		 int Salary = 20000;
		 int bonus = 2000;
		 int total_salary_with_bonus = Salary + bonus ;
		 System.out.println(total_salary_with_bonus);
		
	}
	 public static void showPosition() {
			System.out.println("Showing....");
			
		}
		
}
public class FunctionalInterfaceEx implements Bonus {

	@Override
	public void showSalary() {
		System.out.println("70,00000");
		
	}
	public static void main(String[] args) {
		Bonus.showPosition();
		FunctionalInterfaceEx ex1 = new FunctionalInterfaceEx();
		ex1.calculate_Bonus();
		ex1.showSalary();
	}
	
}
