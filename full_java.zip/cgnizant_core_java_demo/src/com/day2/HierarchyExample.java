package com.day2;
class Parent11{
	public void showParent() {
		System.out.println("parent1 data");
	}
}
class Child11 extends Parent11{
	public void show() {
	System.out.println("showing child 1's data");
	}
}
class Child12 extends Parent11{
	public void show() {
	System.out.println("showing child 2's data");
	}
}
public class HierarchyExample {
	public static void main(String[] args) {
		Child11 c11 = new Child11();
		c11.showParent();
		c11.show();
		Child12 c12 = new Child12();
		c12.show();
		c12.showParent();
	}

}
