package com.day2;
class GrandParent{
	public int sub(int a,int b) {
		int c =  a-b;
		System.out.println(c);
		return c;
	}
}
class Parent extends GrandParent{
	
	public int add(int a,int b) {
		int c =  a+b;
		System.out.println(c);
		return c;
	}
}
class Child extends Parent {
	public int div(int a,int b) {
		int c =  a/b;
		System.out.println(c);
		return c;
	}
	
}
public class InheritanceExample {
	public static void main(String[] args) {
		Child c1 = new Child();
		c1.add(10, 10);
		c1.div(10, 2);
		c1.sub(20, 10);
	}

}
