package com.day6;
//import the sql package
import java.sql.*;

public class CustomerCrudJdbc {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String url = "jdbc:mysql://localhost:3306/bank";
		String user = "root";
		 String pass = "pwd123@";
		 int  no = 104;
		 String name = "Tarun";

		 String query = "select * from customer";
		//load the driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		// establish the connection
		Connection con =  DriverManager.getConnection(url,user,pass);
		
		//create statement
		Statement st = con.createStatement();
		
		//execute the query
		ResultSet result = st.executeQuery(query);
		
		
		// process the result
				int x = st.executeUpdate("insert into customer values('" +name+ "',  '" +no+ "')");
				if (x > 0)			
					System.out.println("Successfully Inserted");			
				else			
					System.out.println("Insert Failed");
				//int x = stmt.executeUpdate("insert into customer values('" +no+ "',  '" +name+ "')");

				

				while(result.next()) {
					System.out.println("Data " + result.getString(1));
					System.out.println("Data " + result.getInt(2));
					
					//System.out.println(result);
				}
		st.close();
		con.close();
		
		
		
		
		
		
		
		
		
		
		
	}
	

}
