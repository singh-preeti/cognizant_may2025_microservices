package com.day6;

import java.sql.*;
import java.util.*;
class AccountCloseApplication 
{
    public static void main (String[]args) throws ClassNotFoundException, SQLException 
    {  
        Scanner sc = new Scanner (System.in);  
        System.out.println ("ENTER ACCOUNT NUMBER");   
        int ano = sc.nextInt ();    
        String url = "jdbc:mysql://localhost:3306/bank";
 		String user = "root";
 		 String pass = "pwd123@";
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection(url,user,pass);
        Statement st = con.createStatement (); 
        int c = st.executeUpdate ("delete from account where accno =" + ano);
        if (c == 0)    
            System.out.println ("account doesnot exist");  
        else
            System.out.println ("account closed successfully");
        st.close ();   
        con.close (); 
    } 
}