package com.day6;

import java.sql.*;

public class PreparedStatementExample {
    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "pwd123@");
             PreparedStatement pstmt = con.prepareStatement("INSERT INTO student (name, age) VALUES (?, ?)")) {

            pstmt.setString(1, "Sushma");
            pstmt.setInt(2, 25);

            int rows = pstmt.executeUpdate();
            System.out.println(rows + " row(s) inserted.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
