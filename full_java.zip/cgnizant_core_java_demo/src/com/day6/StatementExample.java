package com.day6;

import java.sql.*;

public class StatementExample {
    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "pwd123@");
             Statement stmt = con.createStatement()) {

            String name = "Preeti";
            int age = 25;
            // Risky - vulnerable to SQL injection
            String query = "INSERT INTO student (name, age) VALUES ('" + name + "', " + age + ")";
            int rows = stmt.executeUpdate(query);
            System.out.println(rows + " row(s) inserted.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
