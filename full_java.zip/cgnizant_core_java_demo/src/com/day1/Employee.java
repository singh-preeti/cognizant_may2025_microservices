package com.day1;

 class Employee{
	
	protected void displayEmpName() {
		
		System.out.println("All Employee's name are: ");
	}
	public void Caculatesalary(float salary,float bonus) {
		   float total_salary;
		   int year_of_exp = 7;
		   //outer condition
		   if(year_of_exp >=6) {
			   total_salary = salary +  bonus;
			 //  System.out.println(total_salary);
			    if(salary>18000) {
			    	System.out.println(total_salary);
			    }
			    else
			    {
			    	System.out.println("inner else" +salary);
			    }
		   }
		   else
		   {
			   System.out.println("then show just salary" +salary);
		   }
		  
		   
		  // return total_salary;
	}
	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.Caculatesalary(19000, 2000);
		emp.displayEmpName();
	}
}