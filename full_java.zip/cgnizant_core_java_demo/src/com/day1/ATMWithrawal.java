package com.day1;

import java.util.Scanner;

class ATMWithrawal {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		double balance = 2000.0;
		
		System.out.println("Welcome to the Any bank ATM");
		
		System.out.println("Do you want to make a transaction? (yes/no):");
		
		String choice = scan.nextLine();
		
		while(choice.equalsIgnoreCase("YES")) {
			System.out.println("Enter amount to withdraw!");
			double amount = scan.nextDouble();
			scan.nextLine();
			
			if (amount > 0 && amount<= balance) {
				balance -= amount;
				System.out.println("Transaction successful!" +balance);
			}
			else {
				
				System.out.println("Invalid amount. Transaction failed!");
			}
			
			System.out.println("Do you want to makew a transaction? (yes/no):");
			choice = scan.nextLine();
		}
		System.out.println("Thank you for using ATM!");
		scan.close();
	}
}
