package com.day4;

class Address {
    String city;
    String country;

    Address(String city, String country) {
        this.city = city;
        this.country = country;
    }

    // ✅ Copy constructor for Address (deep copy)
    Address(Address original) {
        this.city = original.city;
        this.country = original.country;
    }
}

