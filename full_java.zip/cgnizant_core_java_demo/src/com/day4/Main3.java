package com.day4;

public class Main3 {
    public static void main(String[] args) {
        Address addr1 = new Address("Mumbai", "India");
        Employee emp1 = new Employee("John", addr1);

        // Create a deep copy of emp1
        Employee emp2 = new Employee(emp1);

        System.out.println("Original Employee:");
        emp1.display();

        System.out.println("\nCopied Employee (Deep Copy):");
        emp2.display();

        // Modify address of copied employee
        emp1.address.city = "Delhi";

        System.out.println("\nAfter modifying copied employee's address:");
        emp1.display();  // Unchanged
        emp2.display();  // Changed
    }
}
