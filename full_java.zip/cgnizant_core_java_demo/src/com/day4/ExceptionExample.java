package com.day4;

public class ExceptionExample  {
	// nested try
	public static void main(String[] args)  throws Exception  {
		try {
		System.out.println(1);
		System.out.println(2);
		System.out.println(3/0);
		System.out.println(4);
		System.out.println(5);
		}
//		catch(IndexOutOfBoundsException ex) {
//			System.out.println("exception name is" +ex);
//		}
		catch(ArithmeticException ex1) {
//			System.out.println(ex1);
			ex1.printStackTrace();
		}
		finally{
			System.out.println("realeasing all the resources that is been used ");
		}
	}

}
// exception name, description,line number