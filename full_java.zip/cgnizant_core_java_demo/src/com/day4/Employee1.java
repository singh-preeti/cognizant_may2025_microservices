package com.day4;



class Employee {
    String name;
    Address address;

    // Normal constructor
    Employee(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    // ✅ Deep copy constructor
    Employee(Employee original) {
        this.name = original.name;
        this.address = new Address(original.address);  // Deep copy
    }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("City: " + address.city);
        System.out.println("Country: " + address.country);
    }
}
