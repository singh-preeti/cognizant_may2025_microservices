package com.day4;

class BankAccount {
    private String accountHolder;
    private String accountType;
    private double balance;

    // Normal Constructor
    public BankAccount(String accountHolder, String accountType, double balance) {
        this.accountHolder = accountHolder;
        this.accountType = accountType;
        this.balance = balance;
    }

    // ✅ Copy Constructor
    public BankAccount(BankAccount original) {
        this.accountHolder = original.accountHolder;
        this.accountType = original.accountType;
        this.balance = original.balance;
    }

    public void displayDetails() {
        System.out.println("Holder: " + accountHolder);
        System.out.println("Type: " + accountType);
        System.out.println("Balance: " + balance);
    }
}
