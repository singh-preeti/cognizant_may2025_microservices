package com.module2.day1;

public interface PaymentService {
    boolean processPayment(double amount);
}
