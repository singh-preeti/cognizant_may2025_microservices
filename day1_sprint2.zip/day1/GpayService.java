package com.module2.day1;

import java.util.Random;

public class GpayService implements PaymentService {

    public boolean processPayment(double amount) {
        return new Random().nextBoolean(); // randomly simulate payment success/failure
    }

}
