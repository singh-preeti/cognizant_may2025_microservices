package com.dateapi;

import java.util.*;
public class CalendarDemo2
{
    public static void main (String[]args)
    {
        Calendar calendar = Calendar.getInstance ();
        System.out.println ("At present Calendar's Year: " + calendar.get (Calendar.YEAR));
        System.out.println ("At present Calendar's Day: " + calendar.get (Calendar.DATE));
        System.out.print ("At present Date And Time Is: " + calendar.getTime ());
        int maximum = calendar.getMaximum (Calendar.DAY_OF_WEEK);
        System.out.println ("Maximum number of days in week: " + maximum);
        maximum = calendar.getMaximum (Calendar.WEEK_OF_YEAR);
        System.out.println ("Maximum number of weeks in year: " + maximum);
        int minimum = calendar.getMinimum (Calendar.DAY_OF_WEEK);
        System.out.println ("Minimum number of days in week: " + minimum);
        minimum = calendar.getMinimum (Calendar.WEEK_OF_YEAR);
        System.out.println ("Minimum number of weeks in year: " + minimum);
    }
}