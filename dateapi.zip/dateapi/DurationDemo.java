package com.dateapi;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.time.Duration;
//Duration API in Java
public class DurationDemo
{
    // Function to check duration 
    public static void checkingDuraion ()
    {
        LocalTime time1 = LocalTime.now ();
        System.out.println ("the current time is " + time1);

        Duration fiveHours = Duration.ofHours (5);
        LocalTime time2 = time1.plus (fiveHours);

        System.out.println ("after adding five hours " +"of duration " + time2);

        Duration gap = Duration.between (time2, time1);
        System.out.println ("duraion gap between time1" + " & time2 is " + gap);
    }

    public static void main (String[]args)
    {
        checkingDuraion ();
    }
}