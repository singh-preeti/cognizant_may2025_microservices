package com.day5;

import java.util.ArrayList;
import java.util.List;

public class ArrayListExample {
	public static void main(String[] args) {
		List<Integer> list = new ArrayList();
		list.add(20);
		list.add(new Integer (30));
		list.add(33);
		// [20,30,33]
		//[20,33.33]
		list.add(0,53);
		// [53]
		list.add(1,33);
		
		System.out.println(list.contains(20));
		list.remove(0);
		System.out.println(list.contains(20));
		
		List<String> list1 = new ArrayList();
		list1.add("Tshirt");
		list1.add("Jeans");
		
		
		System.out.println(list);
		System.out.println(list.size());
		System.out.println(list1);
		
		
//		List<Product> cart = new ArrayList();
//		cart.add(new Product("Laptop",40000));
//		cart.add(new Product("Mobile",50000));
//		
//		double total_price = 0;
//		
//		System.out.println("Your cart: ");
//		for(Product prod : cart) {
//			System.out.println(prod.name + " - rupees" + prod.price);
//			total_price += prod.price;
//		}
//		
//		System.out.println("total amount" + total_price);
	}
	
	
	

}
