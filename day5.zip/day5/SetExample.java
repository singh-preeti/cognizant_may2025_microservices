package com.day5;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {
	public static void main(String[] args) {
		
		Set<String> brands = new HashSet();
		brands.add("Levis");
		brands.add("Guess");
		brands.add("UCB");
		brands.add("Allen solly");
		brands.add("Guess");
		brands.add("UCB");
		
		System.out.println("Hash set" +brands);
		
		Set<String> brand_name = new TreeSet();
		brand_name.add("Levis");
		brand_name.add("Guess");
		brand_name.add("UCB");
		brand_name.add("Allen solly");
		brand_name.add("Guess");
		brand_name.add("UCB");
		
		System.out.println("Tree Set" +brand_name);
		
		Set<Integer> price = new HashSet();
		price.add(5000);
		price.add(4000);
		price.add(1000);
		price.add(3000);
		price.add(2000);
		price.add(8000);
		price.add(5000);
		
		System.out.println("hash set" +price);
		
		
		Set<Integer> brand_price = new TreeSet();
		brand_price.add(5000);
		brand_price.add(4000);
		brand_price.add(1000);
		brand_price.add(3000);
		brand_price.add(2000);
		brand_price.add(8000);
		brand_price.add(5000);
		
		System.out.println("Tree Set" +brand_price);
		
		
		
	}

}
