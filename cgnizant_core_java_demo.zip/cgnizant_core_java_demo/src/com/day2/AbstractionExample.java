package com.day2;
 abstract class AbstractDemo{
abstract public void show_Salary();
abstract public void  show_emp_name();
 public void getJob() {
	
	double percentage=75.45;
	if(percentage >= 75) {
	System.out.println("You can go for interview!");}

 }
 }

  class AbstractionExample extends AbstractDemo {
	
	public void show_Salary() {
		System.out.println("70,000");

	}
	@Override
	public void show_emp_name() {
		System.out.println("Preetti Singh");
	}
		
	
	public static void main(String[] args) {
		AbstractionExample abc = new AbstractionExample();
		abc.show_Salary();
		abc.show_emp_name();
	}


}	
	

