package com.day2;
// it can have only abstract methods 
interface ShowSalary{
	
 	void showSalary();
 	
}
interface CalculateSalary{
	public void calculateSalary() ;
}
public class InterfaceExample implements ShowSalary{

	@Override
	public void showSalary() {
		System.out.println("showing...");
	}

	

}
