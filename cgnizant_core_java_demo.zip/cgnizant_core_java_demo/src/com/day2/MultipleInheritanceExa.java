package com.day2;
interface Parent1
{
	public default int div(int a,int b) {
		int c =  a/b;
		System.out.println(c);
		return c;
	}
}
interface Parent2{
	public default int add(int a,int b) {
		int c =  a+b;
		System.out.println(c);
		return c;
	}
}
class Child1 implements Parent1,Parent2 {
	public int sub(int a,int b) {
		int c =  a-b;
		System.out.println(c);
		return c;
	}
}
public class MultipleInheritanceExa {
   public static void main(String[] args) {
	   Child1 c1 = new Child1();
		c1.add(10, 10);
		c1.div(10, 2);
		c1.sub(20, 10);
	}
}

