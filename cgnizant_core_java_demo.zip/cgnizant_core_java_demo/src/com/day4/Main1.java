package com.day4;

public class Main1 {
    public static void main(String[] args) {
        BankAccount original = new BankAccount("Alice", "Savings", 50000.00);

        // ✅ Copying the original account details
        BankAccount jointAccount = new BankAccount(original);

        System.out.println("Original Account:");
        original.displayDetails();

        System.out.println("\nJoint Account (Copied):");
        jointAccount.displayDetails();
    }
}
