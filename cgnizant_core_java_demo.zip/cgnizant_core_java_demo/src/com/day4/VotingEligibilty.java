package com.day4;
class UderAgeException extends RuntimeException {
	UderAgeException()
	{
		super("You are under age!");
	}
//	UderAgeException(String message){
//		super(message);
//	}
}
public class VotingEligibilty {
	public static void main(String[] args) {
		int age = 10;
		try {
			if(age<18)
			{
				throw new UderAgeException();
			}
		}
		catch(UderAgeException e) {
			e.printStackTrace();
			System.out.println(e);
		}
	}

}
