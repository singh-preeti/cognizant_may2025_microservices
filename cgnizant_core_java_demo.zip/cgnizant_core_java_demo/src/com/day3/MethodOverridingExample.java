package com.day3;
abstract class Calculator{
	public abstract int add();
}
public class MethodOverridingExample extends Calculator {

	@Override
	public int add() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
