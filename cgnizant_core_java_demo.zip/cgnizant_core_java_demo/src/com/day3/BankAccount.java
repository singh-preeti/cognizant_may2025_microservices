package com.day3;

public class BankAccount {
	
	private double balance;
	private String acc_holder;
	// constructor
	public BankAccount(double initbalance, String acc_holder) {
		this.acc_holder = acc_holder;
		if(initbalance >= 0) {
			this.balance = initbalance;
		}
		else
		{
			this.balance = 0;
		}
	}
	// for read only
	public double getBalance() {
		return balance;
	}
//	public void setBalance(double balance) {
//		this.balance = balance;
//	}
	
	   // public method to deposit money
	public void deposit(double amount) {
		if(amount>0) {
			balance += amount;
			System.out.println("Deposited" +amount);
			
		}
		else
		{
			System.out.println("Invalid Deposit Amount");
		}
	}
	// public method to withdraw money
	
	public void withdraw (double amount) {
		
		if(amount > 0 && amount <= balance) {
			balance -= amount;
			System.out.println("Withdrawn" + amount);
			
		}
		else
		{
			System.out.println("Insufficient fund");
		}
	}
	public String getAcc_holder() {
		return acc_holder;
	}
	public void setAcc_holder(String acc_holder) {
		this.acc_holder = acc_holder;
	}
	 
	
	
	

}
