package com.day3;

public class Main2 {
    public static void main(String[] args) {
        Address addr = new Address("Mumbai", "India");
        Employee emp1 = new Employee("John", addr);

        // Create a shallow copy
        Employee emp2 = new Employee(emp1);

        System.out.println("Original Employee:");
        emp1.display();

        System.out.println("\nCopied Employee (Shallow):");
        emp2.display();

        // Modify the address in emp2
        emp2.address.city = "Delhi";

        System.out.println("\nAfter modifying copied employee's address:");
        emp1.display();  // Affected due to shallow copy
        emp2.display();
    }
}
