package com.day3;

public class ATMBalanceCheck {
	
	public void checkBalance(int account_number) {
		System.out.println("Checking balance using acc number");
	}
	public void checkBalance(long card_number,int pin) {
		System.out.println("Checking balance using card number and pin");
	}

	public void checkBalance(String mobile_number,String otp) {
		System.out.println("Checking balance using mobile number and OTP");
	}

	public static void main(String[] args) {
		ATMBalanceCheck check = new ATMBalanceCheck();
		check.checkBalance(223456677);
		check.checkBalance(24566677787L, 2289);
		check.checkBalance("8291707543", "6732");
	}
}
