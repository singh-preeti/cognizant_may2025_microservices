package com.day3;

public class MethodOverloadingExample {
	
	// calc example
	// same method name multiple time but use different parameter list
	
	public int add(int a,int b) {
		int c = a+b;
		System.out.println(c);
		return c;
	}
	public int add(float a,float b) {
		int c = (int) (a+b);
		System.out.println();
		return  c;
		
	}
	

	public static void main(String[] args) {
		MethodOverloadingExample obj11 = new MethodOverloadingExample();
		obj11.add(10, 10);
	}
}
